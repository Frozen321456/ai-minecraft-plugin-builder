package me.factory.plugin;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class UtilityCommands implements CommandExecutor {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        // Utility commands primarily target players
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command.", NamedTextColor.RED));
            return true;
        }

        switch (command.getName().toLowerCase()) {
            case "heal" -> {
                return handleHeal(player);
            }
            case "fly" -> {
                return handleFly(player);
            }
            case "gm" -> {
                return handleGamemode(player, args);
            }
        }
        return false;
    }

    private boolean handleHeal(Player player) {
        if (!player.hasPermission("testutility.heal")) {
            player.sendMessage(Component.text("You do not have permission to use this.", NamedTextColor.RED));
            return true;
        }
        
        double maxHealth = 20.0;
        var healthAttr = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (healthAttr != null) {
            maxHealth = healthAttr.getValue();
        }

        player.setHealth(maxHealth);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.sendMessage(Component.text("You have been healed!", NamedTextColor.GREEN));
        return true;
    }

    private boolean handleFly(Player player) {
        if (!player.hasPermission("testutility.fly")) {
            player.sendMessage(Component.text("You do not have permission to use this.", NamedTextColor.RED));
            return true;
        }

        boolean canFly = !player.getAllowFlight();
        player.setAllowFlight(canFly);
        
        if (canFly) {
            player.sendMessage(Component.text("Flight mode enabled.", NamedTextColor.AQUA));
        } else {
            player.sendMessage(Component.text("Flight mode disabled.", NamedTextColor.YELLOW));
        }
        return true;
    }

    private boolean handleGamemode(Player player, String[] args) {
        if (!player.hasPermission("testutility.gamemode")) {
            player.sendMessage(Component.text("You do not have permission to use this.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(Component.text("Usage: /gm <survival|creative|adventure|spectator>", NamedTextColor.RED));
            return true;
        }

        GameMode mode = null;
        String arg = args[0].toLowerCase();

        switch (arg) {
            case "0", "s", "survival" -> mode = GameMode.SURVIVAL;
            case "1", "c", "creative" -> mode = GameMode.CREATIVE;
            case "2", "a", "adventure" -> mode = GameMode.ADVENTURE;
            case "3", "sp", "spectator" -> mode = GameMode.SPECTATOR;
            default -> {
                player.sendMessage(Component.text("Invalid gamemode specified.", NamedTextColor.RED));
                return true;
            }
        }

        player.setGameMode(mode);
        player.sendMessage(Component.text("Gamemode updated to " + mode.name().toLowerCase(), NamedTextColor.GREEN));
        return true;
    }
}