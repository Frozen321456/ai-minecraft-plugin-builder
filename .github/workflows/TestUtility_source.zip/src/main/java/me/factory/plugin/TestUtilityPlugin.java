package me.factory.plugin;

import org.bukkit.plugin.java.JavaPlugin;
import java.util.Objects;

public class TestUtilityPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // Register commands
        UtilityCommands commands = new UtilityCommands();
        Objects.requireNonNull(getCommand("heal")).setExecutor(commands);
        Objects.requireNonNull(getCommand("fly")).setExecutor(commands);
        Objects.requireNonNull(getCommand("gm")).setExecutor(commands);

        getLogger().info("TestUtility has been enabled successfully!");
    }

    @Override
    public void onDisable() {
        getLogger().info("TestUtility has been disabled.");
    }
}